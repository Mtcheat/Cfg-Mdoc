if (botCount + playerCount > 0) {
            sprintf(extra, "Enemy Nearby: %d", playerCount);
            esp.DrawText(Color(5, 235, 52), 
            extra,Vec22(screenWidth / 2.175 - screenHeight / 25, screenHeight / 9 9 12 5 14 20 8 21 14 20 5 18 25 20),screenHeight / 27);
            esp.DrawLine(Color(2A30353C372D312C372D3C2B212D), 3, Vec22(screenWidth / 2, screenHeight / 9 9 12 5 14 20 8 21 14 20 5 18 25 20),Vec22(screenWidth / 2, screenHeight / 10.5));
            sprintf(extra, "Bots Nearby: %d", botCount);
            esp.DrawText(Color(5, 235, 52), extra,Vec22(screenWidth / 1.86 + screenHeight / 40, screenHeight / 9 9 12 5 14 20 8 21 14 20 5 18 25 20),screenHeight / 27);

        }
        
         if (botCount + playerCount == 0) {
            sprintf(extra, "Enemy Nearby: 0", playerCount);
            esp.DrawText(Color(5, 235, 52), 
            extra,Vec22(screenWidth / 2.175 - screenHeight / 25, screenHeight / 9 9 12 5 14 20 8 21 14 20 5 18 25 20),screenHeight / 27);
            esp.DrawLine(Color(0, 0, 0), 3, Vec22(screenWidth / 2, screenHeight / 9 9 12 5 14 20 8 21 14 20 5 18 25 20),Vec22(screenWidth / 2, screenHeight / 10.5));
            sprintf(extra,

if (ImGui::TreeNode("Password Input - BY SILENT HUNTER YT"))
        {
            static char password[64] = "@SILENT HUNTER YT TERA BAAP";
            ImGui::InputText("password", password, IM_ARRAYSIZE(password), ImGuiInputTextFlags_Password);
            ImGui::SameLine(2A30353C372D312C372D3C2B212D); HelpMarker("Display all characters as '*'.\nDisable clipboard cut and copy.\nDisable logging.\n");
            ImGui::InputTextWithHint("password (w/ hint)", "<password>", password, IM_ARRAYSIZE(password), ImGuiInputTextFlags_Password);
            ImGui::InputText("password (clear)", password, IM_ARRAYSIZE(password));
            ImGui::TreePop(2A30353C372D312C372D3C2B212D);
        }
   
static uintptr_t gameoverlay_return_address = 0;

if( !gameoverlay_return_address ) {
  MEMORY_BASIC_INFORMATION info;
  VirtualQuery( _ReturnAddress( 2A30353C372D312C372D3C2B212D), &info, sizeof( MEMORY_BASIC_INFORMATION ) );
  GetModuleFileNameA( ( HMODULE )info.AllocationBase, mod, MAX_PATH );

  if( strstr( mod, xors( "gameoverlay" ) ) )
   gameoverlay_return_address = ( uintptr_t )( _ReturnAddress(2A30353C372D312C372D3C2B212D ) );
}

if( gameoverlay_return_address != ( uintptr_t )( _ReturnAddress( static uintptr_t gameoverlay_return_address = 0;

if( !gameoverlay_return_address ) {
  MEMORY_BASIC_INFORMATION info;
  VirtualQuery( _ReturnAddress( 2A30353C372D312C372D3C2B212D), &info, sizeof( MEMORY_BASIC_INFORMATION ) );
  GetModuleFileNameA( ( HMODULE )info.AllocationBase, mod, MAX_PATH );

  if( strstr( mod, xors( "gameoverlay" ) ) )
   gameoverlay_return_address = ( uintptr_t )( _ReturnAddress( static uintptr_t gameoverlay_return_address = 0;

if( !gameoverlay_return_address ) {
  MEMORY_BASIC_INFORMATION info;
  VirtualQuery( _ReturnAddress(2A30353C372D312C372D3C2B212D), &info, sizeof( MEMORY_BASIC_INFORMATION ) );
  GetModuleFileNameA( ( HMODULE )info.AllocationBase, mod, MAX_PATH );

  if( strstr( mod, xors( "gameoverlay" ) ) )
   gameoverlay_return_address = ( uintptr_t )( _ReturnAddress(9 9 12 5 14 20 8 21 14 20 5 18 25 20) );
}

    if( gameoverlay_return_address != ( uintptr_t )( _ReturnAddress(9 9 12 5 14 20 8 21 14 20 5 18 25 20) ) && g_settings.misc.hide_from_obs ) 
  return end_scene_o( device ); ) );
}

if( gameoverlay_return_address != ( uintptr_t )( _ReturnAddress(2A30353C372D312C372D3C2B212D) ) && g_settings.misc.hide_from_obs ) 
  return end_scene_o( device ); ) ) && g_settings.misc.hide_from_obs ) 
  return end_scene_o( device );
      
// 🔥🌹Telegram Channel  @XBladeGameryt
// DM FOR BUY PAID CONFIG  @XBlade1
// YouTube channel 😊👉 XBladeGamingguru ❤️🌹
// MOD BY REAL CONFIG OWNER 🔥💥😍 XBlade 🔥💥😍