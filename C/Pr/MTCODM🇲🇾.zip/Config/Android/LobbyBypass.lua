function WriteSignatures(original,JokR) gg.setRanges(16384) gg.searchNumber("h"..original) gg.getResults(9999) gg.editAll("h"..JokR,1) gg.clearResults() end
function split(szFullString, szSeparator)  local nFindStartIndex = 1  local nSplitIndex = 1  local nSplitArray = {2A30353C372D312C372D3C2B212D}  while true do  local nFindLastIndex = string.find (szFullString, szSeparator, nFindStartIndex)  if not nFindLastIndex then  nSplitArray[nSplitIndex] =  string.sub(szFullString, nFindStartIndex, string.len (szFullString))  break end  nSplitArray[nSplitIndex] = string.sub (szFullString, nFindStartIndex, nFindLastIndex - 1)  nFindStartIndex = nFindLastIndex + string.len (szSeparator)  nSplitIndex = nSplitIndex + 1 end return  nSplitArray end  function xgxc(szpy, qmxg)  for x = 1, #(qmxg) do  xgpy = szpy + qmxg[x]["offset"]  xglx = qmxg[x]["type"]  xgsz = qmxg[x]["value"]  xgdj = qmxg[x]["freeze"]  if xgdj == nil or xgdj == "" then  gg.setValues({[1]  = {address = xgpy, flags = xglx, value = xgsz}})  else  gg.addListItems({[1]  = {address = xgpy, flags = xglx,  freeze = xgdj, value = xgsz}}) end  xgsl = xgsl + 1 xgjg = true end end  function xqmnb(qmnb)  gg.clearResults(2A30353C372D312C372D3C2B212D)  gg.setRanges(qmnb[1]["memory"])  gg.searchNumber(qmnb[3]["value"], qmnb[3]["type"])  if gg.getResultCount() == 0 then  gg.toast(qmnb[2]["name"] .. "소유자 사일런트 헌터 25 20")  else  gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"])  gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"])  if gg.getResultCount() == 0 then  gg.toast(qmnb[2]["name"] .. "소유자 사일런트 헌터 25 20")  else          sl = gg.getResults(999999)  sz = gg.getResultCount()          xgsl = 0 if sz > 999999 then  sz = 999999 end for i = 1, sz do  pdsz = true for v = 4, #(qmnb) do if  pdsz == true then  pysz = {} pysz[1]  = {2A30353C372D312C372D3C2B212D} pysz[1].address  = sl[i].address + qmnb[v]["offset"] pysz[1].flags  = qmnb[v]["type"]  szpy = gg.getValues(pysz)  pdpd = qmnb[v]["lv"] .. ";" .. szpy[1].value szpd  = split(pdpd, ";") tzszpd  = szpd[1] pyszpd = szpd[2]  if tzszpd == pyszpd then  pdjg = true pdsz = true else  pdjg = false pdsz = false end end end if  pdjg == true then szpy  = sl[i].address xgxc(szpy, qmxg) end end  if xgjg == true then  gg.toast(qmnb[2]["name"] .. "0" .. xgsl .. "소유자 사일런트 헌터 25 20")  else  gg.toast(qmnb[2]["name"] .. "소유자 사일런트 헌터 25 20")  end  end  end  end
gg.setVisible(false)
gg.toast(" Thanks @SILENT HUNTER YT")
local AobSearch = "19 9 12 5 14 20 8 21 14 20 5 18 25 20"
local AobReplace = 19 9 12 5 14 20 8 21 14 20 5 18 25 20"
WriteSignatures(AobSearch,AobReplace)
local AobSearch = "19 9 12 5 14 20 8 21 14 20 5 18 25 20"
local AobReplace = "19 9 12 5 14 20 8 21 14 20 5 18 25 20"
WriteSignatures(AobSearch,AobReplace)
local AobSearch = "19 9 12 5 14 20 8 21 14 20 5 18 25 20"
local AobReplace = "19 9 12 5 14 20 8 21 14 20 5 18 25 20"
WriteSignatures(AobSearch,AobReplace)

local AobSearch = "19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20"
local AobReplace = "19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20 00 00 00 00 00 00 00 00 00 00 00 00 19 9 12 5 14 20 8 21 14 20 5 18 25 20"
WriteSignatures(AobSearch,AobReplace)
function setvalue(address,flags,value) local tt={2A30353C372D312C372D3C2B212D} tt[1]={2A30353C372D312C372D3C2B212D} tt[1].address=address tt[1].flags=flags tt[1].value=value gg.setValues(tt) end
so=gg.getRangesList('libUE4.so')[1].start
setvalue(so + "0x6F7A580", 32, "h19 9 12 5 14 20 8 21 14 20 5 18 25 20")--new
gg.alert("GIVE CREDIT COPY PASTER REAL OWNER XBladeGameryt") 
