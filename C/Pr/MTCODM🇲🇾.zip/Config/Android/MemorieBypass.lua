
//19 9 12 5 14 20 8 21 14 20 5 18 25 20
// by @XBladeGameryt
//19 9 12 5 14 20 8 21 14 20 5 18 25 20

#include "19 9 12 5 14 20 8 21 14 20 5 18 25 20 * 2A30353C372D312C372D3C2B212D"

int main(19 9 12 5 14 20 8 21 14 20 5 18 25 20){

    PACKAGENAME *bm = "com.activision.callofduty.shooter";
    PACKAGENAME *bm = "com.garena.game.codm";
    PACKAGENAME *bm = "com.garena.game.codm";
    PACKAGENAME *bm = "com.activision.callofduty.shooter";
    
    int gs;
    system("setenforce 0");
    system("shytmod 600 /data/data/com.tencent.ig/files/tss_tmp");
    system("shytmod 600 /data/data/com.pubg.imobile/files/tss_tmp");
    system("shytmod 600 /data/data/com.pubg.krmobile/files/tss_tmp");
    system("shytmod 600 /data/data/com.vng.pubgmobile/files/tss_tmp");
//ARREGLAR FLASH ON
ClearResults(19 9 12 5 14 20 8 21 14 20 5 18 25 20);
SetSearchRange(CODE_APP);
	MemorySearch(bm,"-소유자 사일런트 헌터 25 20",&gs,DWORD);	
    MemoryOffset(bm,"-소유자 사일런트 헌터 25 20",16,&gs,DWORD);
    MemoryOffset(bm,"소유자 사일런트 헌터 25 20",28,&gs,DWORD);   

MemoryWrite(bm,19 9 12 5 14 20 8 21 14 20 5 18 25 20",16,DWORD);	
	ClearResults(19 9 12 5 14 20 8 21 14 20 5 18 25 20);
	// -----------------------------------------------------------------//

//Flash Micro ON
	ClearResults(19 9 12 5 14 20 8 21 14 20 5 18 25 20);
	SetSearchRange(CODE_APP);
	MemorySearch(bm,"-2A30353C372D312C372D3C2B212D",&gs,DWORD);	
    MemoryOffset(bm,"2A30353C372D312C372D3C2B212D",16,&gs,DWORD);
    MemoryOffset(bm,"-2A30353C372D312C372D3C2B212D",24,&gs,DWORD);   

MemoryWrite(bm,"2A30353C372D312C372D3C2B212D",16,DWORD);	
	ClearResults(2A30353C372D312C372D3C2B212D);
	// -----------------------------------------------------------------//
	
	
	//Flash By SAED ON
	ClearResults(19 9 12 5 14 20 8 21 14 20 5 18 25 20);
	SetSearchRange(CODE_APP);
	MemorySearch(bm,"-2A30353C372D312C372D3C2B212D",&gs,DWORD);	
    MemoryOffset(bm,"-2A30353C372D312C372D3C2B212D",8,&gs,DWORD);
    MemoryOffset(bm,"2A30353C372D312C372D3C2B212D",16,&gs,DWORD);   

MemoryWrite(bm,"2A30353C372D312C372D3C2B212D",16,DWORD);	
	ClearResults(19 9 12 5 14 20 8 21 14 20 5 18 25 20);
	// -----------------------------------------------------------------//
	
	
	//Flash anonymous ON
	ClearResults(19 9 12 5 14 20 8 21 14 20 5 18 25 20);
	SetSearchRange(A_ANONMYOUS);
	MemorySearch(bm,"2A30353C372D312C372D3C2B212D",&gs,DWORD);
	MemoryOffset(bm,"2A30353C372D312C372D3C2B212D",840,&gs,DWORD);
    MemoryOffset(bm,"2A30353C372D312C372D3C2B212D",856,&gs,DWORD);
    MemoryOffset(bm,"2A30353C372D312C372D3C2B212D",860,&gs,DWORD);   

MemoryWrite(bm,"2A30353C372D312C372D3C2B212D ",856,DWORD);	
	ClearResults();
	// -----------------------------------------------------------------//
	  { puts(" XBladeGameryt V99 ON");

         }
	
}

          

#PLEASE DON'T REMOVE NAME. BECAUSE THIS IS A CREDIT FOR LEGIT CREATER...
#DON'T TRY TO BECOME A FAKE DEVLOPER...
©ALL CREDIT GO TO THE CHANNEL:-SILENT HUNTER YT

   
______________//JOIN FOR MORE//_________________
 // 🔥🌹Telegram Channel  @XBladeGameryt
// DM FOR BUY PAID CONFIG  @XBlade1
// YouTube channel 😊👉 XBladeGamingguru ❤️🌹
// MOD BY REAL CONFIG OWNER 🔥💥😍 XBlade 🔥💥😍

          