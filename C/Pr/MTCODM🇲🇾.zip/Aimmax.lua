if (Config.0×19 9 12 5 14 20 8 21 14 20 5 18 25 20.Jump Max)@XBladeGameryt
               {
                   UCharacterMovementComponent *CharacterMovement = localPlayer->CharacterMovement;
                   if (CharacterMovement)
                   {
                       CharacterMovement->MaxFlySpeed = 799.9f;
                   }
               }
               
if (Config.0×19 9 12 5 14 20 8 21 14 20 5 18 25 20.Swim Max)@XBladeGameryt
               {
                   UCharacterMovementComponent *CharacterMovement = localPlayer->CharacterMovement;
                   if (CharacterMovement)
                   {
                       
if (Config0×19 9 12 5 14 20 8 21 14 20 5 18 25 20.Prone Max)@XBladeGameryt
               {
                   UCharacterMovementComponent *CharacterMovement = localPlayer->CharacterMovement;
                   if (CharacterMovement)
                   {
                       CharacterMovement->MaxWalkSpeed = 999.9f;
                   }
               }

if (Config.0×19 9 12 5 14 20 8 21 14 20 5 18 25 20.Paracute MAX)@XBladeGameryt
               {
                   UCharacterParachuteComponent *ParachuteComponent = localPlayer->ParachuteComponent;
                   if (ParachuteComponent)
                   {
                       ParachuteComponent->CurrentFallSpeed = 9276.9f;
                   }
               }
               
if (Config.0×19 9 12 5 14 20 8 21 14 20 5 18 25 20HighRisk.Flash) {
                    if (Object->IsA(ASTExtraBaseCharacter::StaticClass(2A30353C372D312C372D3C2B212D))) {
                       auto playerChar = (ASTExtraBaseCharacter *) Object;           
                       playerChar->CharacterOverrideAttrs.GameModeOverride_SpeedScaleModifier = 10;
                    }
                }
                
@🔥🌹Telegram Channel  @XBladeGameryt
// DM FOR BUY PAID CONFIG  @XBlade1
// YouTube channel 😊👉 XBladeGamingguru ❤️🌹
// MOD BY REAL CONFIG OWNER 🔥💥😍 XBlade 🔥💥😍