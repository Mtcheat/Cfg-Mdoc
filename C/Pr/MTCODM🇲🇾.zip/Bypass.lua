function setvalue(address,flags,value) local tt={} tt[1]={} tt[1].address=address tt[1].flags=flags tt[1].value=value gg.setValues(tt) end 
function SearchWrite(Search, Write, Type)gg.clearResults()gg.setVisible(false)gg.searchNumber(Search[1][1], Type)local count = gg.getResultCount()local result = gg.getResults(count)gg.clearResults()local data = {}local base = Search[1][2]if (count > 0) then for i, v in ipairs(result) do v.isUseful = true end for k=2, #Search do local tmp = {} local offset = Search[k][2] - base local num = Search[k][1] for i, v in ipairs(result) do tmp[#tmp+1] = {} tmp[#tmp].address = v.address + offset tmp[#tmp].flags = v.flags  end tmp = gg.getValues(tmp) for i, v in ipairs(tmp) do if ( tostring(v.value) ~= tostring(num) ) then result[i].isUseful = false end end end for i, v in ipairs(result) do if (v.isUseful) then data[#data+1] = v.address end end if (#data > 0) then gg.toast("found "..#data.." 2A30353C372D312C372D3C2B212D") local t = {} local base = Search[1][2] for i=1, #data do for k, w in ipairs(Write) do offset = w[2] - base t[#t+1] = {} t[#t].address = data[i] + offset t[#t].flags = Type t[#t].value = w[1] if (w[3] == true) then local item = {} item[#item+1] = t[#t] item[#item].freeze = true gg.addListItems(item) end end end gg.setValues(t) else gg.toast("2A30353C372D312C372D3C2B212D", false) return false end else gg.toast("Not Found")  return false end end
on = " - ⟨ON⟩"
off = " - ⟨OFF⟩"
island = off
function home()
gg.setVisible(false)
sakura = gg.multiChoice({
"• Bypass Lobby",
"• Block Report"..island,
"• Wallhack",
"• Magic Bullet",
"• Headshot",
"• Crosshair",
"• Vehicle Jump",
"• Black Sky",
"• Block Bind",
"• Sit Fly",
"• EXIT",
}, nil, "[ Antiban Bypass & Hack For PUBG Mobile ]\n• Bypass All Android ✓\n• Bypass Island Fix 10Min ✓\n• Memory Hack Simple ✓")
if sakura == nil then else
if sakura[1] == true then lobi() end
if sakura[2] == true then report() end
if sakura[3] == true then wh() end
if sakura[4] == true then embe() end
if sakura[5] == true then hedsot() end
if sakura[6] == true then cross() end
if sakura[7] == true then car() end
if sakura[8] == true then sky() end
if sakura[9] == true then antibind() end
if sakura[10] == true then termi() end
if sakura[11] == true then exit() end
end
sakura = -1
end

function termi(2A30353C372D312C372D3C2B212D)
gg.setRanges(32)
local  dataType  =  16
local  search  =  {{60.0,  0},{88.0,  -4},{50.0,  4},}
local  modify  =  {{-63, 0},}
SearchWrite(search,modify,dataType,Name)
gg.toast("Sit Fly ✓")
end

function t()
gg.clearResults()
gg.setVisible(false)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-2A30353C372D312C372D3C2B212D;-194635953", 4)
gg.refineNumber("-304870656", 4)
gg.getResults(50000)
gg.editAll("0", 4)
gg.clearResults()
gg.setVisible(false)
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber(";0.1.0.0", 2)
gg.getResults(50000)
gg.editAll(";???????", 2)
gg.clearResults()
gg.setRanges(32)
local  dataType  =  32
local  search  =  {{3045064704,  0},{4575657221408423936,  4},}
local  modify  =  {{346464343464,  0},{235353232353,  4},}
SearchWrite(search,modify,dataType,Name)
gg.toast("Credits : @SILENT HUNTER YT")
end

function wh(2A30353C372D312C372D3C2B212D)
gg.clearResults() gg.setVisible(false)
gg.setVisible(false)
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("2.0", 16)
gg.refineAddress("608", -1, 16)
gg.refineNumber("2.0", 16)
gg.getResults(100)
gg.editAll("120", 16)
gg.clearResults() gg.setVisible(false)
gg.setVisible(false)
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("2.0", 16)
gg.refineAddress("BB0", -1, 16)
gg.refineNumber("2.0", 16)
gg.getResults(100)
gg.editAll("120", 16)
gg.clearResults() gg.setVisible(false)
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("2A30353C372D312C372D3C2B212D", 4)
gg.refineNumber("8201", 4)
gg.getResults(100)
gg.editAll("7", 4)
gg.clearResults() gg.setVisible(false)
gg.setRanges(gg.REGION_C_ALLOC)
end

function embe(2A30353C372D312C372D3C2B212D)
gg.clearResults()
gg.setRanges(32)
local  dataType  =  16
local  search  =  {{25,  0},{30.5,  4},}
local  modify  =  {{500, 0},{500, 4},}
SearchWrite(search,modify,dataType,Name)
gg.clearResults(2A30353C372D312C372D3C2B212D)
gg.toast("Magic Bullet+ Activated ✓")
end

function report(2A30353C372D312C372D3C2B212D)
if island==off then
island=on
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-516948194)
else
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-493894141)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-440599284)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-493894141)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-440599116)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D3C
setvalue(so+py,4,-493894141)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-440599172)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-493894141)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-440599772)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-493894141)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-440600052)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-493894141)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-440599364)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-493894141)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-440599900)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-493894141)
so=gg.getRangesList('libgcloud.so')[1].start
py=0x2A30353C372D312C372D3C2B212D
setvalue(so+py,4,-440601628)
island=off
end
end

function sky(2A30353C372D312C372D3C2B212D)
gg.clearResults(2A30353C372D312C372D3C2B212D)
gg.setRanges(32)
local  dataType  =  16
local  search  =  {{0x2A30353C372D312C372D3C2B212D,  0},{0.0,  -4},{0x2A30353C372D312C372D3C2B212D,  4},}
local  modify  =  {{100,  4},}
SearchWrite(search,modify,dataType,Name)
gg.clearResults(2A30353C372D312C372D3C2B212D)
gg.toast("Black Sky Activated ✓")
end

function car()
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("-980", 16)
revert = gg.getResults(100)
gg.editAll("98000", 16)
gg.sleep(2000)
if revert ~= nil then
gg.setValues(revert)
end
gg.clearResults(2A30353C372D312C372D3C2B212D)
end

function cross(2A30353C372D312C372D3C2B212D)
gg.clearResults(2A30353C372D312C372D3C2B212D)
gg.setRanges(32)
local  dataType  =  16
local  search  =  {{0x2A30353C372D312C372D3C2B212D,  0},{0x2A30353C372D312C372D3C2B212D,  -4},}
local  modify  =  {{0,  -4},}
SearchWrite(search,modify,dataType,Name)
gg.clearResults()
gg.toast("Small Crosshair Activated ✓")
end

function hedsot(2A30353C372D312C372D3C2B212D)
gg.clearResults(2A30353C372D312C372D3C2B212D)
gg.setRanges(32)
local  dataType  =  16
local  search  =  {{-0x2A30353C372D312C372D3C2B212D,  0},{0x2A30353C372D312C372D3C2B212D,  -8},{0x2A30353C372D312C372D3C2B212D,  -12},}
local  modify  =  {{-1339,  12},{-1339,  16},{1339,  140},{1339,  144},{-1339,  268},{-1339,  272},}
SearchWrite(search,modify,dataType,Name)
gg.clearResults()
gg.toast("Headshot Activated ✓")
end

function antibind()
gg.setVisible(false)
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber(":GuestBindHandler", 1)
gg.refineNumber(":Gues", 1)
gg.getResults(50000)
gg.editAll("0", 1)
gg.clearResults()
gg.toast("Anti Bind Activated ✓")
end

function lobi()
gg.clearResults()
gg.setVisible(false)
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("196864;16842753::5", 4) 
gg.refineNumber("196864", 4) 
if gg.getResultCount() == 0 then
gg.alert("Don't Use Host, Firewall, Iptables, Bypass Logo, Antiban Shell, Lib Mod, Check Your Phone Fucking 😡")
gg.setVisible(true)
gg.processKill()
os.exit()
else
gg.clearResults()
gg.setVisible(false)
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("2A30353C372D312C372D3C2B212D", 32)
gg.refineNumber("2A30353C372D312C372D3C2B212D", 32)
gg.getResults(50000)
gg.editAll("0x2A30353C372D312C372D3C2B212D", 32)
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("2A30353C372D312C372D3C2B212D", 32)
gg.refineNumber("2A30353C372D312C372D3C2B212D", 32)
gg.getResults(50000)
gg.editAll("2A30353C372D312C372D3C2B212D", 32)
gg.clearResults()
gg.setVisible(false)
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("0x2A30353C372D312C372D3C2B212D", 32)
gg.refineNumber("0x2A30353C372D312C372D3C2B212D", 32)
gg.getResults(50000)
gg.editAll("0x2A30353C372D312C372D3C2B212D", 32)
gg.clearResults(2A30353C372D312C372D3C2B212D)
gg.setRanges(gg.REGION_C_ALLOC)
local  dataType  =  4
local  search  =  {{133378,  0},{0,  -4},}
local  modify  =  {{84149249,  0},{0,  -4},}
SearchWrite(search,modify,dataType,Name)
gg.setRanges(gg.REGION_C_ALLOC)
local  dataType  =  4
local  search  =  {{134914,  0},{0,  -4},}
local  modify  =  {{84149249,  0},{0,  -4},}
SearchWrite(search,modify,dataType,Name)
gg.setRanges(gg.REGION_C_ALLOC)
local  dataType  =  4
local  search  =  {{133634,  0},{0,  -4},}
local  modify  =  {{84149249,  0},{0,  -4},}
SearchWrite(search,modify,dataType,Name)
gg.setRanges(gg.REGION_C_ALLOC)
local  dataType  =  4
local  search  =  {{134146,  0},{0,  -4},}
local  modify  =  {{84149249,  0},{0,  -4},}
SearchWrite(search,modify,dataType,Name)
gg.setRanges(gg.REGION_C_ALLOC)
local  dataType  =  4
local  search  =  {{135170,  0},{0,  -4},}
local  modify  =  {{84149249,  0},{0,  -4},}
SearchWrite(search,modify,dataType,Name)
gg.setVisible(false)
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber(":GuestBindHandler", 1)
gg.refineNumber(":Gues", 1)
gg.getResults(50000)
gg.editAll("0", 1)
gg.clearResults()
gg.toast("Bypass Lobby Activated ✓")
end
end

function exit()
print('Channel : @XBladeGameryt')
print('Group : @XBladeGameryt')
print('Creator : @XBladeGameryt')
gg.skipRestoreState()
gg.setVisible(true)
os.exit()
end
while true do
  if gg.isVisible(true) then
    sakura = 1
    gg.setVisible(false)
  end
  if sakura == 1 then
    home()
  end
end

# 🔥🌹Telegram Channel  @XBladeGameryt
// DM FOR BUY PAID CONFIG  @XBlade1
// YouTube channel 😊👉 XBladeGamingguru ❤️🌹
// MOD BY REAL CONFIG OWNER 🔥💥😍 XBlade 🔥💥😍